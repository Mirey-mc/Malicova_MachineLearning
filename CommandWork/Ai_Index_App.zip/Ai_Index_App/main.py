from fastapi import FastAPI
from pydantic import BaseModel
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

app = FastAPI(title="AI Index API")
df = pd.read_csv("AI_index_db.csv")
features = [
    "Talent",
    "Infrastructure",
    "Operating Environment",
    "Research",
    "Development",
    "Government Strategy",
    "Commercial"
]
X = df[features]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

model = KMeans(n_clusters=5, random_state=42, n_init=10)
model.fit(X_scaled)

class CountryData(BaseModel):
    Talent: float
    Infrastructure: float
    Operating_Environment: float
    Research: float
    Development: float
    Government_Strategy: float
    Commercial: float

@app.get("/")
def home():
    return {
        "message": "AI Index API работает"
    }

@app.post("/predict")
def predict(data: CountryData):

    values = [[
        data.Talent,
        data.Infrastructure,
        data.Operating_Environment,
        data.Research,
        data.Development,
        data.Government_Strategy,
        data.Commercial
    ]]

    values_scaled = scaler.transform(values)

    prediction = model.predict(values_scaled)

    return {
        "cluster": int(prediction[0])
    }