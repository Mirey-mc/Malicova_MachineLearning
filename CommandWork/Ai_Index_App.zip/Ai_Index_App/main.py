from fastapi import FastAPI
from pydantic import BaseModel
import pandas as pd
import numpy as np

from sklearn.preprocessing import StandardScaler
from sklearn.mixture import GaussianMixture

app = FastAPI(
    title="AI Index API",
    description="API для предсказания кластера страны"
)

df = pd.read_csv("AI_index_db.csv")

features = [
    "Talent",
    "Infrastructure",
    "Operating Environment",
    "Research",
    "Development",
    "Government Strategy",
    "Commercial"
]

X = df[features]


scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

model = GaussianMixture(
    n_components=5,
    random_state=42
)

model.fit(X_scaled)

class CountryData(BaseModel):

    Talent: float
    Infrastructure: float
    Operating_Environment: float
    Research: float
    Development: float
    Government_Strategy: float
    Commercial: float

def predict_cluster(data):

    values = np.array([[
        data.Talent,
        data.Infrastructure,
        data.Operating_Environment,
        data.Research,
        data.Development,
        data.Government_Strategy,
        data.Commercial
    ]])

    # Стандартизация
    values_scaled = scaler.transform(values)

    # Предсказанный кластер
    prediction = model.predict(values_scaled)

    # Вероятности принадлежности
    probabilities = model.predict_proba(values_scaled)

    cluster = int(prediction[0])

    probabilities = probabilities[0].tolist()

    return cluster, probabilities


@app.get("/")
def home():

    return {
        "message": "AI Index API работает"
    }


@app.post("/predict")
def predict(data: CountryData):

    cluster, probabilities = predict_cluster(data)

    return {
        "cluster": cluster,
        "probabilities": probabilities
    }