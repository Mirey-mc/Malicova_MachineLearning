import streamlit as st
import pandas as pd
import requests

st.set_page_config(
    page_title="AI Index",
    layout="wide"
)

st.title("Анализ индекса искусственного интеллекта")
st.write(
    "Интерактивное приложение для анализа показателей "
    "развития искусственного интеллекта в странах."
)

df = pd.read_csv("AI_index_db.csv")
features = [
    "Talent",
    "Infrastructure",
    "Operating Environment",
    "Research",
    "Development",
    "Government Strategy",
    "Commercial"
]

st.subheader("Выбор страны")

country = st.selectbox(
    "Выберите страну:",
    df["Country"].tolist()
)
row = df[df["Country"] == country].iloc[0]
st.subheader("Основные показатели")
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric(
        "Total score",
        round(row["Total score"], 2)
    )

with col2:
    st.metric(
        "Talent",
        round(row["Talent"], 2)
    )

with col3:
    st.metric(
        "Infrastructure",
        round(row["Infrastructure"], 2)
    )

with col4:
    st.metric(
        "Commercial",
        round(row["Commercial"], 2)
    )
st.subheader("Информация о стране")

info_col1, info_col2, info_col3 = st.columns(3)

with info_col1:
    st.write("**Регион:**", row["Region"])

with info_col2:
    st.write("**Группа дохода:**", row["Income group"])

with info_col3:
    st.write("**Политический режим:**", row["Political regime"])

st.subheader("Основные показатели развития ИИ")

chart_data = pd.DataFrame({
    "Показатель": features,
    "Значение": [
        row["Talent"],
        row["Infrastructure"],
        row["Operating Environment"],
        row["Research"],
        row["Development"],
        row["Government Strategy"],
        row["Commercial"]
    ]
})

st.bar_chart(
    chart_data.set_index("Показатель")
)

st.subheader("Сравнение со средними значениями")

comparison_data = pd.DataFrame({
    "Показатель": features,
    "Выбранная страна": [
        row["Talent"],
        row["Infrastructure"],
        row["Operating Environment"],
        row["Research"],
        row["Development"],
        row["Government Strategy"],
        row["Commercial"]
    ],
    "Среднее по странам": [
        df["Talent"].mean(),
        df["Infrastructure"].mean(),
        df["Operating Environment"].mean(),
        df["Research"].mean(),
        df["Development"].mean(),
        df["Government Strategy"].mean(),
        df["Commercial"].mean()
    ]
})

st.dataframe(
    comparison_data.round(2),
    use_container_width=True,
    hide_index=True
)
st.subheader("Топ-10 стран по индексу ИИ")

top10 = (
    df[["Country", "Total score"]]
    .sort_values("Total score", ascending=False)
    .head(10)
)

top10_chart = top10.set_index("Country")
st.bar_chart(top10_chart)
st.dataframe(
    top10.round(2),
    use_container_width=True,
    hide_index=True
)

st.subheader("Сравнение стран")
col1, col2 = st.columns(2)
with col1:
    country1 = st.selectbox(
        "Первая страна:",
        df["Country"].tolist(),
        index=0
    )
with col2:
    country2 = st.selectbox(
        "Вторая страна:",
        df["Country"].tolist(),
        index=1
    )
row1 = df[df["Country"] == country1].iloc[0]
row2 = df[df["Country"] == country2].iloc[0]

comparison_countries = pd.DataFrame({
    "Показатель": features,
    country1: [
        row1["Talent"],
        row1["Infrastructure"],
        row1["Operating Environment"],
        row1["Research"],
        row1["Development"],
        row1["Government Strategy"],
        row1["Commercial"]
    ],
    country2: [
        row2["Talent"],
        row2["Infrastructure"],
        row2["Operating Environment"],
        row2["Research"],
        row2["Development"],
        row2["Government Strategy"],
        row2["Commercial"]
    ]
})

st.dataframe(
    comparison_countries.round(2),
    use_container_width=True,
    hide_index=True
)
st.subheader("Определение кластера")
st.write("Для выбранной страны модель машинного обучения "
    "определяет принадлежность к одному из кластеров."
)

if st.button("Определить кластер"):

    data = {
        "Talent": float(row["Talent"]),
        "Infrastructure": float(row["Infrastructure"]),
        "Operating_Environment": float(
            row["Operating Environment"]
        ),
        "Research": float(row["Research"]),
        "Development": float(row["Development"]),
        "Government_Strategy": float(
            row["Government Strategy"]
        ),
        "Commercial": float(row["Commercial"])
    }
    try:

        response = requests.post(
            "http://127.0.0.1:8000/predict",
            json=data
        )

        if response.status_code == 200:

            result = response.json()

            cluster = result["cluster"]

            st.success(
                f"Страна «{country}» относится к кластеру №{cluster}"
            )

        else:

            st.error(
                "Ошибка при обращении к FastAPI."
            )

    except requests.exceptions.ConnectionError:

        st.error(
            "Не удалось подключиться к FastAPI. "
            "Убедитесь, что main.py запущен."
        )