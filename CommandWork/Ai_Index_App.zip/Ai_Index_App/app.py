import streamlit as st
import pandas as pd
import requests

st.set_page_config(
    page_title="AI Index",
    layout="wide"
)

st.title("Анализ индекса искусственного интеллекта")
st.write(
    "Анализ показателей развития искусственного интеллекта "
    "и предсказание принадлежности страны к кластеру.")

df = pd.read_csv("AI_index_db.csv")
features = [
    "Talent",
    "Infrastructure",
    "Operating Environment",
    "Research",
    "Development",
    "Government Strategy",
    "Commercial"
]
st.subheader("Выбор страны")
country = st.selectbox(
    "Выберите страну:",
    df["Country"].tolist()
)

row = df[df["Country"] == country].iloc[0]

st.subheader("Основные показатели")
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric(
        "Total score",
        round(row["Total score"], 2)
    )

with col2:
    st.metric(
        "Talent",
        round(row["Talent"], 2)
    )

with col3:
    st.metric(
        "Infrastructure",
        round(row["Infrastructure"], 2)
    )

with col4:
    st.metric(
        "Commercial",
        round(row["Commercial"], 2)
    )

st.subheader("Информация о стране")
col1, col2, col3 = st.columns(3)

with col1:
    st.write("**Регион:**", row["Region"])

with col2:
    st.write("**Группа дохода:**", row["Income group"])

with col3:
    st.write("**Политический режим:**", row["Political regime"])

st.subheader("Показатели развития ИИ")

chart_data = pd.DataFrame({
    "Показатель": features,
    "Значение": [
        row["Talent"],
        row["Infrastructure"],
        row["Operating Environment"],
        row["Research"],
        row["Development"],
        row["Government Strategy"],
        row["Commercial"]
    ]
})

st.bar_chart(
    chart_data.set_index("Показатель")
)

st.subheader("Сравнение со средними значениями")
comparison_data = pd.DataFrame({
    "Показатель": features,

    "Выбранная страна": [
        row["Talent"],
        row["Infrastructure"],
        row["Operating Environment"],
        row["Research"],
        row["Development"],
        row["Government Strategy"],
        row["Commercial"]
    ],

    "Среднее по странам": [
        df["Talent"].mean(),
        df["Infrastructure"].mean(),
        df["Operating Environment"].mean(),
        df["Research"].mean(),
        df["Development"].mean(),
        df["Government Strategy"].mean(),
        df["Commercial"].mean()
    ]
})

st.dataframe(
    comparison_data.round(2),
    use_container_width=True,
    hide_index=True
)

st.subheader("Топ-10 стран по индексу ИИ")

top10 = (
    df[["Country", "Total score"]]
    .sort_values(
        "Total score",
        ascending=False
    )
    .head(10)
)

st.bar_chart(
    top10.set_index("Country")
)

st.dataframe(
    top10.round(2),
    use_container_width=True,
    hide_index=True
)

st.subheader("Сравнение стран")
col1, col2 = st.columns(2)
with col1:

    country1 = st.selectbox(
        "Первая страна:",
        df["Country"].tolist(),
        index=0
    )

with col2:

    country2 = st.selectbox(
        "Вторая страна:",
        df["Country"].tolist(),
        index=1
    )


row1 = df[df["Country"] == country1].iloc[0]
row2 = df[df["Country"] == country2].iloc[0]


comparison_countries = pd.DataFrame({

    "Показатель": features,

    country1: [
        row1["Talent"],
        row1["Infrastructure"],
        row1["Operating Environment"],
        row1["Research"],
        row1["Development"],
        row1["Government Strategy"],
        row1["Commercial"]
    ],

    country2: [
        row2["Talent"],
        row2["Infrastructure"],
        row2["Operating Environment"],
        row2["Research"],
        row2["Development"],
        row2["Government Strategy"],
        row2["Commercial"]
    ]
})


st.dataframe(
    comparison_countries.round(2),
    use_container_width=True,
    hide_index=True
)

st.divider()

st.subheader("Предсказание кластера")
st.write(
    "На основе показателей выбранной страны "
    "модель определяет наиболее вероятный кластер."
)
st.write("### Показатели страны")
col1, col2 = st.columns(2)
with col1:

    talent = st.number_input(
        "Talent",
        value=float(row["Talent"]),
        min_value=0.0
    )

    infrastructure = st.number_input(
        "Infrastructure",
        value=float(row["Infrastructure"]),
        min_value=0.0
    )

    operating_environment = st.number_input(
        "Operating Environment",
        value=float(row["Operating Environment"]),
        min_value=0.0
    )

    research = st.number_input(
        "Research",
        value=float(row["Research"]),
        min_value=0.0
    )


with col2:

    development = st.number_input(
        "Development",
        value=float(row["Development"]),
        min_value=0.0
    )

    government_strategy = st.number_input(
        "Government Strategy",
        value=float(row["Government Strategy"]),
        min_value=0.0
    )

    commercial = st.number_input(
        "Commercial",
        value=float(row["Commercial"]),
        min_value=0.0
    )

if st.button("Предсказать кластер"):

    data = {

        "Talent": talent,

        "Infrastructure": infrastructure,

        "Operating_Environment":
            operating_environment,

        "Research": research,

        "Development": development,

        "Government_Strategy":
            government_strategy,

        "Commercial": commercial
    }


    try:

        response = requests.post(
            "http://127.0.0.1:8000/predict",
            json=data
        )


        if response.status_code == 200:

            result = response.json()

            cluster = result["cluster"]

            probabilities = result["probabilities"]
            st.success(
                f"Предсказанный кластер: {cluster}"
            )


            st.subheader(
                "Вероятности принадлежности к кластерам"
            )
            probability_data = pd.DataFrame({

                "Кластер": [
                    "Кластер 0",
                    "Кластер 1",
                    "Кластер 2",
                    "Кластер 3",
                    "Кластер 4"
                ],
                "Вероятность": [
                    round(probabilities[0] * 100, 2),
                    round(probabilities[1] * 100, 2),
                    round(probabilities[2] * 100, 2),
                    round(probabilities[3] * 100, 2),
                    round(probabilities[4] * 100, 2)
                ]
            })
            st.dataframe(
                probability_data,
                use_container_width=True,
                hide_index=True
            )
            st.bar_chart(
                probability_data.set_index("Кластер")
            )
        else:

            st.error(
                "Ошибка при обращении к FastAPI."
            )


    except requests.exceptions.ConnectionError:

        st.error(
            "Не удалось подключиться к FastAPI. "
            "Сначала запустите main.py."
        )
